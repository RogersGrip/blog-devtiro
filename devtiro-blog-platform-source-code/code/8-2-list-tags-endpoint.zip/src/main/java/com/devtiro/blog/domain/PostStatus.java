package com.devtiro.blog.domain;

public enum PostStatus {
    DRAFT, PUBLISHED
}
